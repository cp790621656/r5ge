Note: The library originally contained all 187 files in the root folder.
That's obviously far from ideal, and was the reason they were separated into sub-folders.
The library should build in MSVC 2005 & 2008 (pro and express), as well as XCode as-is.
To build on Linux, you may need to move all files in Include, Source, and Misc folders
into a single folder first.